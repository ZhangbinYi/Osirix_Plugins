#ifndef A_h
#define A_h
template <class T> class A { public: static T Method(); };
#endif

